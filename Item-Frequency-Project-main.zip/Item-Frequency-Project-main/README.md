# Item-Frequency-Project
Lets show you my skills 
